from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_required, current_user
from extensions import db
from models import Site, Template
from sqlalchemy import func
import re

user_bp = Blueprint("user", __name__, url_prefix="/user")

def _slugify(text: str) -> str:
    text = re.sub(r"[^a-zA-Z0-9ก-๙\s-]", "", text)
    text = text.strip().replace(" ", "-")
    return text.lower() or "site"


@user_bp.route("/dashboard")
@login_required
def dashboard():
    sites = Site.query.filter_by(owner_id=current_user.id).order_by(Site.created_at.desc()).all()
    site_count = len(sites)
    return render_template("dashboard_user.html", sites=sites, site_count=site_count)


@user_bp.route("/create", methods=["GET", "POST"])
@login_required
def create_site():
    # เช็คจำนวนเว็บไซต์ก่อน
    site_count = Site.query.filter_by(owner_id=current_user.id).count()
    if site_count >= current_user.site_limit:
        flash("คุณสร้างเว็บไซต์ครบจำนวนที่กำหนดแล้ว", "danger")
        return redirect(url_for("user.dashboard"))

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        mode = request.form.get("mode", "template")
        template_id = request.form.get("template_id")

        if not name:
            flash("กรุณากรอกชื่อเว็บไซต์", "danger")
            return redirect(url_for("user.create_site"))

        slug_base = _slugify(name)
        slug = slug_base
        # ทำให้ slug ไม่ซ้ำในเจ้าของเดียวกัน
        i = 1
        while Site.query.filter_by(owner_id=current_user.id, slug=slug).first():
            slug = f"{slug_base}-{i}"
            i += 1

        site = Site(
            owner_id=current_user.id,
            name=name,
            slug=slug,
            mode=mode,
        )

        if mode == "template" and template_id:
            tpl = Template.query.get(int(template_id))
            if tpl:
                site.template_id = tpl.id
                site.html_content = tpl.html_content
                site.css_content = tpl.css_content
                site.js_content = tpl.js_content

        if mode == "code":
            site.html_content = "<!-- เขียนโค้ด HTML ของคุณที่นี่ -->"
            site.css_content = "/* เขียนโค้ด CSS ของคุณที่นี่ */"
            site.js_content = "// เขียนโค้ด JavaScript ของคุณที่นี่"

        db.session.add(site)
        db.session.commit()
        flash("สร้างเว็บไซต์สำเร็จแล้ว", "success")
        return redirect(url_for("user.edit_site", site_id=site.id))

    templates = Template.query.order_by(Template.id.asc()).all()
    return render_template("create_site.html", templates=templates)


@user_bp.route("/edit/<int:site_id>", methods=["GET", "POST"])
@login_required
def edit_site(site_id):
    site = Site.query.filter_by(id=site_id, owner_id=current_user.id).first_or_404()

    if request.method == "POST":
        site.name = request.form.get("name", site.name).strip() or site.name
        site.html_content = request.form.get("html_content", site.html_content)
        site.css_content = request.form.get("css_content", site.css_content)
        site.js_content = request.form.get("js_content", site.js_content)
        db.session.commit()
        flash("บันทึกการแก้ไขเว็บไซต์แล้ว", "success")
        return redirect(url_for("user.edit_site", site_id=site.id))

    return render_template("edit_site.html", site=site)


@user_bp.route("/delete/<int:site_id>", methods=["POST"])
@login_required
def delete_site(site_id):
    site = Site.query.filter_by(id=site_id, owner_id=current_user.id).first_or_404()
    db.session.delete(site)
    db.session.commit()
    flash("ลบเว็บไซต์เรียบร้อยแล้ว", "info")
    return redirect(url_for("user.dashboard"))
