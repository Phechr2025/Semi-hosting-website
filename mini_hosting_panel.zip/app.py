from flask import Flask, render_template
from extensions import db, login_manager
from models import User, Template
from flask_login import current_user
import os

def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-key")
    app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get(
        "DATABASE_URL", "sqlite:///hosting.db"
    )
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)
    login_manager.init_app(app)

    from auth import auth_bp
    from user_routes import user_bp
    from admin_routes import admin_bp
    from site_routes import site_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(user_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(site_bp)

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    @app.route("/")
    def index():
        return render_template("index.html")

    with app.app_context():
        db.create_all()
        _ensure_default_admin()
        _ensure_default_templates()

    return app


def _ensure_default_admin():
    # สร้าง admin เริ่มต้นจากระบบโดยตรง ถ้ายังไม่มี
    admin_username = os.environ.get("DEFAULT_ADMIN_USER", "admin")
    admin_password = os.environ.get("DEFAULT_ADMIN_PASS", "admin123")
    admin = User.query.filter_by(role="admin").first()
    if not admin:
        admin = User(username=admin_username, role="admin", site_limit=50)
        admin.set_password(admin_password)
        db.session.add(admin)
        db.session.commit()
        print(f"[INIT] Created default admin: {admin_username} / {admin_password}")


def _ensure_default_templates():
    # ถ้ายังไม่มี template เลย ให้สร้างไว้สัก 5 แบบ (เพิ่มเองภายหลังได้)
    if Template.query.count() > 0:
        return

    base_templates = [
        {
            "name": "Landing Page Simple",
            "category": "Landing",
            "html_content": """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Landing Page</title>
</head>
<body>
  <header>
    <h1>ยินดีต้อนรับสู่เว็บไซต์ของคุณ</h1>
    <p>นี่คือตัวอย่าง Landing Page แบบเรียบง่าย</p>
  </header>
  <section>
    <h2>หัวข้อเด่น</h2>
    <p>แก้ไขเนื้อหานี้ได้จากหน้าแก้ไขเว็บไซต์ในระบบโฮสติ้งของคุณ</p>
  </section>
  <footer>
    <p>© 2025 My Mini Hosting</p>
  </footer>
</body>
</html>""",
            "css_content": """body { font-family: sans-serif; margin: 0; padding: 0; }
header { background: linear-gradient(90deg,#6366f1,#a855f7); color:white; padding:40px 20px; text-align:center; }
section { padding:20px; max-width:800px; margin:0 auto; }
footer { text-align:center; padding:10px; background:#f1f5f9; font-size:14px; }""",
            "js_content": "",
        },
        {
            "name": "Portfolio Minimal",
            "category": "Portfolio",
            "html_content": """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>My Portfolio</title>
</head>
<body>
  <header>
    <h1>My Portfolio</h1>
    <p>แสดงผลงานของคุณที่นี่</p>
  </header>
  <main>
    <div class="grid">
      <div class="card">
        <h3>Project 1</h3>
        <p>คำอธิบายสั้น ๆ ของโปรเจกต์</p>
      </div>
      <div class="card">
        <h3>Project 2</h3>
        <p>คำอธิบายสั้น ๆ ของโปรเจกต์</p>
      </div>
    </div>
  </main>
</body>
</html>""",
            "css_content": """body { font-family: system-ui, sans-serif; margin:0; background:#0f172a; color:#e5e7eb; }
header { padding:32px 16px; text-align:center; border-bottom:1px solid #1f2937; }
.grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:16px; padding:20px; max-width:900px; margin:0 auto; }
.card { background:#111827; border-radius:12px; padding:16px; box-shadow:0 10px 20px rgba(0,0,0,0.4); }""",
            "js_content": "",
        },
        {
            "name": "Blog Simple",
            "category": "Blog",
            "html_content": """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>My Blog</title>
</head>
<body>
  <nav>
    <h1>My Blog</h1>
  </nav>
  <main>
    <article>
      <h2>โพสต์แรกของฉัน</h2>
      <p>คุณสามารถแก้ไขข้อความนี้ได้เองในภายหลัง</p>
    </article>
  </main>
</body>
</html>""",
            "css_content": """body { font-family: 'Prompt', system-ui, sans-serif; background:#f9fafb; margin:0; }
nav { background:#111827; color:#f9fafb; padding:16px 24px; }
main { max-width:720px; margin:24px auto; background:white; padding:24px; border-radius:12px; box-shadow:0 10px 25px rgba(15,23,42,.1); }""",
            "js_content": "",
        },
        {
            "name": "Business Clean",
            "category": "Business",
            "html_content": """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Business</title>
</head>
<body>
  <header class="hero">
    <h1>ชื่อธุรกิจของคุณ</h1>
    <p>สโลแกนสั้น ๆ ที่น่าสนใจ</p>
  </header>
  <section class="features">
    <div class="feature">
      <h3>บริการ 1</h3>
      <p>รายละเอียดบริการ</p>
    </div>
    <div class="feature">
      <h3>บริการ 2</h3>
      <p>รายละเอียดบริการ</p>
    </div>
  </section>
</body>
</html>""",
            "css_content": """body { margin:0; font-family:system-ui, sans-serif; }
.hero { padding:60px 20px; text-align:center; background:#0ea5e9; color:white; }
.features { display:flex; flex-wrap:wrap; gap:16px; justify-content:center; padding:20px; }
.feature { flex:1 1 220px; max-width:260px; background:white; border-radius:12px; padding:16px; box-shadow:0 4px 12px rgba(15,23,42,.1); }""",
            "js_content": "",
        },
        {
            "name": "One Page CV",
            "category": "Profile",
            "html_content": """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>My CV</title>
</head>
<body>
  <div class="wrapper">
    <h1>ชื่อ - นามสกุล</h1>
    <p>ตำแหน่ง / สายงาน</p>
    <h2>ประสบการณ์</h2>
    <ul>
      <li>ปี xxxx - xxxx : บริษัท / โปรเจกต์</li>
    </ul>
    <h2>ทักษะ</h2>
    <p>Python, Web, Design, etc.</p>
  </div>
</body>
</html>""",
            "css_content": """body { background:#e5e7eb; margin:0; font-family:system-ui,sans-serif; }
.wrapper { max-width:720px; margin:24px auto; background:white; padding:24px; border-radius:16px; box-shadow:0 10px 30px rgba(15,23,42,.15); }""",
            "js_content": "",
        },
    ]

    for t in base_templates:
        tpl = Template(
            name=t["name"],
            category=t.get("category"),
            thumbnail=None,
            html_content=t["html_content"],
            css_content=t["css_content"],
            js_content=t["js_content"],
        )
        db.session.add(tpl)

    db.session.commit()
    print("[INIT] Created default templates")


if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
