from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_required, current_user
from extensions import db
from models import User, Site

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


def admin_required(func):
    from functools import wraps

    @wraps(func)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash("สำหรับผู้ดูแลระบบเท่านั้น", "danger")
            return redirect(url_for("auth.login"))
        return func(*args, **kwargs)

    return wrapper


@admin_bp.route("/dashboard")
@login_required
@admin_required
def dashboard():
    user_count = User.query.count()
    site_count = Site.query.count()
    users = User.query.order_by(User.created_at.desc()).limit(10).all()
    return render_template(
        "dashboard_admin.html",
        user_count=user_count,
        site_count=site_count,
        recent_users=users,
    )


@admin_bp.route("/users", methods=["GET", "POST"])
@login_required
@admin_required
def manage_users():
    query = request.args.get("q", "").strip()
    q = User.query
    if query:
        q = q.filter(User.username.ilike(f"%{query}%"))

    users = q.order_by(User.created_at.desc()).all()
    return render_template("admin_users.html", users=users, query=query)


@admin_bp.route("/user/<int:user_id>/edit", methods=["GET", "POST"])
@login_required
@admin_required
def edit_user(user_id):
    user = User.query.get_or_404(user_id)
    if request.method == "POST":
        site_limit = request.form.get("site_limit", type=int, default=user.site_limit)
        role = request.form.get("role", user.role)

        user.site_limit = site_limit
        user.role = role
        db.session.commit()
        flash("บันทึกข้อมูลผู้ใช้แล้ว", "success")
        return redirect(url_for("admin.manage_users"))

    return render_template("admin_edit_user.html", user=user)


@admin_bp.route("/user/<int:user_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("ไม่สามารถลบบัญชีแอดมินของตนเองได้", "danger")
        return redirect(url_for("admin.manage_users"))

    # ลบเว็บไซต์ทั้งหมดของผู้ใช้ก่อน
    for site in list(user.sites):
        db.session.delete(site)

    db.session.delete(user)
    db.session.commit()
    flash("ลบบัญชีผู้ใช้และเว็บไซต์ทั้งหมดของเขาเรียบร้อยแล้ว", "info")
    return redirect(url_for("admin.manage_users"))
