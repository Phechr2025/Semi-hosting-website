# Mini Hosting Panel (Flask)

ระบบโฮสติ้งขนาดเล็กสำหรับให้ผู้ใช้สมัครสมาชิกและสร้างเว็บไซต์ของตัวเองได้
เริ่มต้นจำกัดที่ 2 เว็บไซต์ต่อบัญชี และผู้ดูแลระบบ (Admin) สามารถปรับเพิ่ม/ลดได้

## ฟีเจอร์หลัก

- สมัครสมาชิก / ล็อกอิน / ล็อกเอาต์
- ผู้ใช้แต่ละคน:
  - สร้างเว็บไซต์ได้สูงสุด 2 เว็บ (ค่าเริ่มต้น)
  - เลือกโหมดสร้าง:
    - จากเทมเพลต
    - เขียนโค้ดเอง (HTML/CSS/JS)
    - หน้าเปล่า
  - แก้ไข / ลบเว็บของตนเองได้
- เว็บไซต์แต่ละเว็บเข้าถึงได้ผ่าน URL:

  http://your-domain.com/site/<username>/<slug>

- แอดมิน:
  - มีเพียงผู้ที่ถูกกำหนดจากระบบเท่านั้น (สร้างอัตโนมัติครั้งแรก)
  - ดูจำนวนผู้ใช้/เว็บไซต์ทั้งหมด
  - ค้นหาผู้ใช้ตามชื่อ
  - ปรับ role (user/admin)
  - ปรับจำนวนเว็บที่สร้างได้ (site_limit)
  - ลบบัญชีผู้ใช้ พร้อมลบเว็บไซต์ทั้งหมดของเขา

## การติดตั้งบน VPS (Ubuntu)

1) ติดตั้ง dependency พื้นฐาน

    sudo apt update && sudo apt install -y python3 python3-venv python3-pip

2) ดาวน์โหลดโปรเจกต์จาก GitHub (ตัวอย่าง)

    git clone https://github.com/yourname/mini-hosting-panel.git
    cd mini-hosting-panel

3) สร้าง virtualenv และติดตั้งแพ็กเกจ

    python3 -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt

4) รันแอป

    python app.py

แอปจะเปิดที่พอร์ต 8000 (แก้ได้ในไฟล์ app.py หรือใช้ตัวแปรแวดล้อม PORT)

## แอดมินเริ่มต้น

เมื่อรันครั้งแรก ระบบจะสร้างบัญชีแอดมินให้อัตโนมัติ:

- username: admin
- password: admin123

ค่าเริ่มต้นสามารถเปลี่ยนได้ผ่านตัวแปรแวดล้อม:

    export DEFAULT_ADMIN_USER="myadmin"
    export DEFAULT_ADMIN_PASS="strongpassword"
    export SECRET_KEY="random-secret-key"
    python app.py

จากนั้นเข้าใช้งาน:

- หน้าแรก: http://your-vps-ip:8000/
- แผงแอดมิน: http://your-vps-ip:8000/admin/dashboard
- แดชบอร์ดผู้ใช้: http://your-vps-ip:8000/user/dashboard
