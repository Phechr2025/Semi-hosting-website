from flask import Blueprint, render_template
from models import Site, User

site_bp = Blueprint("site", __name__)


@site_bp.route("/site/<username>/<slug>")
def view_site(username, slug):
    user = User.query.filter_by(username=username).first_or_404()
    site = Site.query.filter_by(
        owner_id=user.id, slug=slug, is_published=True
    ).first_or_404()
    return render_template("view_site.html", site=site, owner=user)
