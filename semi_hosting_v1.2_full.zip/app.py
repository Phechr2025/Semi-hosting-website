from flask import Flask, render_template
from extensions import db, login_manager
from models import User, Template
import os


def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-key")
    app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get(
        "DATABASE_URL", "sqlite:///hosting_v1_2.db"
    )
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)
    login_manager.init_app(app)

    from auth import auth_bp
    from user_routes import user_bp
    from admin_routes import admin_bp
    from site_routes import site_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(user_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(site_bp)

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    @app.route("/")
    def index():
        return render_template("index.html")

    with app.app_context():
        db.create_all()
        _ensure_default_admin()
        _ensure_default_templates()

    return app


def _ensure_default_admin():
    admin_username = os.environ.get("DEFAULT_ADMIN_USER", "admin")
    admin_password = os.environ.get("DEFAULT_ADMIN_PASS", "admin123")
    admin = User.query.filter_by(role="admin").first()
    if not admin:
        admin = User(username=admin_username, role="admin", site_limit=50)
        admin.set_password(admin_password)
        db.session.add(admin)
        db.session.commit()
        print(f"[INIT] Created default admin: {admin_username} / {admin_password}")


def _ensure_default_templates():
    if Template.query.count() > 0:
        return

    base_templates = []

    def add_template(name, category, html_body, css_body):
        base_templates.append(
            {
                "name": name,
                "category": category,
                "html_content": html_body,
                "css_content": css_body,
                "js_content": "",
            }
        )

    # 1: Simple Landing
    add_template(
        "Landing Page Simple",
        "Landing",
        """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Landing Page</title>
</head>
<body>
  <header class="hero">
    <h1>ยินดีต้อนรับสู่เว็บไซต์ของคุณ</h1>
    <p>นี่คือตัวอย่าง Landing Page แบบเรียบง่าย</p>
    <a href="#feature" class="btn-primary">เริ่มต้นเลย</a>
  </header>
  <section id="feature" class="section">
    <h2>หัวข้อเด่น</h2>
    <p>แก้ไขเนื้อหานี้ได้จากหน้าแก้ไขเว็บไซต์ในระบบโฮสติ้งของคุณ</p>
  </section>
</body>
</html>""",
        """body { font-family: system-ui, sans-serif; margin: 0; background:#020617; color:#e5e7eb; }
.hero { padding: 60px 20px; text-align:center; background: linear-gradient(90deg,#6366f1,#a855f7); }
.section { padding: 32px 20px; max-width:800px; margin:0 auto; }
.btn-primary { display:inline-block; margin-top:16px; padding:10px 20px; border-radius:999px; background:#0f172a; color:white; text-decoration:none; }""",
    )

    # 2: Portfolio Grid
    add_template(
        "Portfolio Grid",
        "Portfolio",
        """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>My Portfolio</title>
</head>
<body>
  <header class="topbar">
    <h1>My Portfolio</h1>
    <p>แสดงผลงานของคุณอย่างสวยงาม</p>
  </header>
  <main class="grid">
    <article class="card"><h3>Project 1</h3><p>คำอธิบายสั้น ๆ</p></article>
    <article class="card"><h3>Project 2</h3><p>คำอธิบายสั้น ๆ</p></article>
    <article class="card"><h3>Project 3</h3><p>คำอธิบายสั้น ๆ</p></article>
  </main>
</body>
</html>""",
        """body { margin:0; font-family:system-ui,sans-serif; background:#020617; color:#e5e7eb;}
.topbar { padding:32px 16px; text-align:center; border-bottom:1px solid #1f2937;}
.grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:20px; padding:24px; max-width:1000px; margin:0 auto;}
.card { background:#0f172a; border-radius:16px; padding:16px; box-shadow:0 10px 25px rgba(15,23,42,.5);}""",
    )

    # 3: Blog Simple
    add_template(
        "Blog Simple",
        "Blog",
        """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>My Blog</title>
</head>
<body>
  <nav class="navbar">
    <h1>My Blog</h1>
  </nav>
  <main class="content">
    <article>
      <h2>โพสต์แรกของฉัน</h2>
      <p>คุณสามารถแก้ไขข้อความนี้ได้เองในภายหลัง</p>
    </article>
  </main>
</body>
</html>""",
        """body { margin:0; font-family:'Prompt',system-ui,sans-serif; background:#f3f4f6;}
.navbar { background:#111827; color:#f9fafb; padding:16px 24px;}
.content { max-width:720px; margin:24px auto; background:white; padding:24px; border-radius:12px; box-shadow:0 10px 25px rgba(15,23,42,.1);}""",
    )

    # 4: Business Clean
    add_template(
        "Business Clean",
        "Business",
        """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Business</title>
</head>
<body>
  <header class="hero">
    <h1>ชื่อธุรกิจของคุณ</h1>
    <p>สโลแกนสั้น ๆ ที่น่าสนใจ</p>
  </header>
  <section class="features">
    <div class="feature">
      <h3>บริการ 1</h3>
      <p>รายละเอียดบริการ</p>
    </div>
    <div class="feature">
      <h3>บริการ 2</h3>
      <p>รายละเอียดบริการ</p>
    </div>
  </section>
</body>
</html>""",
        """body { margin:0; font-family:system-ui,sans-serif; }
.hero { padding:60px 20px; text-align:center; background:#0ea5e9; color:white; }
.features { display:flex; flex-wrap:wrap; gap:16px; justify-content:center; padding:20px; }
.feature { flex:1 1 220px; max-width:260px; background:white; border-radius:12px; padding:16px; box-shadow:0 4px 12px rgba(15,23,42,.1);}""",
    )

    # 5: One Page CV
    add_template(
        "One Page CV",
        "Profile",
        """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>My CV</title>
</head>
<body>
  <div class="wrapper">
    <h1>ชื่อ - นามสกุล</h1>
    <p>ตำแหน่ง / สายงาน</p>
    <h2>ประสบการณ์</h2>
    <ul>
      <li>ปี xxxx - xxxx : บริษัท / โปรเจกต์</li>
    </ul>
    <h2>ทักษะ</h2>
    <p>Python, Web, Design, etc.</p>
  </div>
</body>
</html>""",
        """body { background:#e5e7eb; margin:0; font-family:system-ui,sans-serif;}
.wrapper { max-width:720px; margin:24px auto; background:white; padding:24px; border-radius:16px; box-shadow:0 10px 30px rgba(15,23,42,.15);}""",
    )

    # 6: Ecommerce Simple
    add_template(
        "Ecommerce Simple",
        "Shop",
        """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>My Shop</title>
</head>
<body>
  <header class="shop-header">
    <h1>My Shop</h1>
    <p>ขายสินค้าง่าย ๆ ด้วยหน้าเว็บเดียว</p>
  </header>
  <section class="products">
    <div class="product">
      <h3>สินค้า 1</h3>
      <p>รายละเอียดสินค้า</p>
      <span class="price">฿199</span>
    </div>
    <div class="product">
      <h3>สินค้า 2</h3>
      <p>รายละเอียดสินค้า</p>
      <span class="price">฿299</span>
    </div>
  </section>
</body>
</html>""",
        """body{margin:0;font-family:system-ui,sans-serif;background:#f8fafc;}
.shop-header{text-align:center;padding:32px;background:#111827;color:#f9fafb;}
.products{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px;padding:20px;max-width:900px;margin:0 auto;}
.product{background:white;border-radius:12px;padding:16px;box-shadow:0 10px 25px rgba(15,23,42,.08);}
.price{font-weight:bold;color:#16a34a;}""",
    )

    # 7: Coming Soon
    add_template(
        "Coming Soon",
        "Landing",
        """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Coming Soon</title>
</head>
<body>
  <div class="center">
    <h1>Coming Soon</h1>
    <p>เว็บไซต์กำลังอยู่ระหว่างการพัฒนา</p>
  </div>
</body>
</html>""",
        """body{margin:0;height:100vh;display:flex;align-items:center;justify-content:center;background:#020617;color:#e5e7eb;font-family:system-ui,sans-serif;}
.center{text-align:center;padding:24px;border-radius:18px;border:1px solid #1e293b;box-shadow:0 20px 45px rgba(15,23,42,.7);}""",
    )

    # 8: Docs Page
    add_template(
        "Docs Page",
        "Docs",
        """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Documentation</title>
</head>
<body>
  <aside class="sidebar">
    <h2>หัวข้อ</h2>
    <ul>
      <li>เริ่มต้นใช้งาน</li>
      <li>การติดตั้ง</li>
      <li>ตัวอย่างโค้ด</li>
    </ul>
  </aside>
  <main class="docs">
    <h1>หัวข้อหลัก</h1>
    <p>เขียนคู่มือหรือเอกสารของคุณที่นี่</p>
  </main>
</body>
</html>""",
        """body{margin:0;display:flex;font-family:system-ui,sans-serif;}
.sidebar{width:220px;background:#020617;color:#e5e7eb;padding:16px;}
.docs{flex:1;padding:24px;background:#f9fafb;}""",
    )

    # 9: Photo Gallery
    add_template(
        "Photo Gallery",
        "Gallery",
        """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Gallery</title>
</head>
<body>
  <header class="gallery-header">
    <h1>Gallery</h1>
  </header>
  <section class="gallery">
    <div class="item"></div>
    <div class="item"></div>
    <div class="item"></div>
    <div class="item"></div>
  </section>
</body>
</html>""",
        """body{margin:0;font-family:system-ui,sans-serif;background:#020617;color:#e5e7eb;}
.gallery-header{text-align:center;padding:24px;}
.gallery{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;padding:12px;}
.item{background:linear-gradient(135deg,#22c55e,#06b6d4);border-radius:16px;height:140px;}""",
    )

    # 10: Hero + Features
    add_template(
        "Hero Features",
        "Landing",
        """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Hero Page</title>
</head>
<body>
  <section class="hero">
    <h1>หัวข้อใหญ่โดดเด่น</h1>
    <p>ข้อความอธิบายสั้น ๆ ชวนให้น่าสนใจ</p>
  </section>
  <section class="cols">
    <div class="col"><h3>จุดเด่น 1</h3><p>รายละเอียด</p></div>
    <div class="col"><h3>จุดเด่น 2</h3><p>รายละเอียด</p></div>
    <div class="col"><h3>จุดเด่น 3</h3><p>รายละเอียด</p></div>
  </section>
</body>
</html>""",
        """body{margin:0;font-family:system-ui,sans-serif;background:#020617;color:#e5e7eb;}
.hero{padding:60px 20px;text-align:center;background:radial-gradient(circle at top,#4f46e5,#0f172a);}
.cols{display:flex;flex-wrap:wrap;gap:16px;max-width:900px;margin:24px auto;padding:0 16px;}
.col{flex:1 1 240px;background:#0f172a;padding:16px;border-radius:16px;box-shadow:0 16px 30px rgba(15,23,42,.8);}""",
    )

    # 11: Simple Dashboard
    add_template(
        "Simple Dashboard",
        "App",
        """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Dashboard</title>
</head>
<body>
  <nav class="nav">Dashboard</nav>
  <main class="dash">
    <div class="card"><h3>สถิติ 1</h3><p>ค่า x</p></div>
    <div class="card"><h3>สถิติ 2</h3><p>ค่า y</p></div>
    <div class="card"><h3>สถิติ 3</h3><p>ค่า z</p></div>
  </main>
</body>
</html>""",
        """body{margin:0;font-family:system-ui,sans-serif;background:#020617;color:#e5e7eb;}
.nav{padding:14px 20px;background:#0f172a;border-bottom:1px solid #1e293b;}
.dash{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;padding:20px;}
.card{background:#0b1120;border-radius:16px;padding:16px;box-shadow:0 15px 30px rgba(15,23,42,.8);}""",
    )

    # 12: FAQ Page
    add_template(
        "FAQ Page",
        "Support",
        """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>FAQ</title>
</head>
<body>
  <header class="header">
    <h1>คำถามที่พบบ่อย</h1>
  </header>
  <section class="faq">
    <article>
      <h3>ถาม 1</h3>
      <p>คำตอบ...</p>
    </article>
    <article>
      <h3>ถาม 2</h3>
      <p>คำตอบ...</p>
    </article>
  </section>
</body>
</html>""",
        """body{margin:0;font-family:system-ui,sans-serif;background:#f9fafb;}
.header{text-align:center;padding:32px;}
.faq{max-width:800px;margin:0 auto;padding:0 16px 32px;}
article{background:white;margin-bottom:12px;padding:16px;border-radius:12px;box-shadow:0 8px 16px rgba(15,23,42,.06);}""",
    )

    # 13: Contact Page
    add_template(
        "Contact Page",
        "Contact",
        """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Contact</title>
</head>
<body>
  <section class="contact">
    <h1>ติดต่อเรา</h1>
    <p>กรอกข้อมูลติดต่อด้านล่าง</p>
    <form>
      <input type="text" placeholder="ชื่อของคุณ">
      <input type="email" placeholder="อีเมล">
      <textarea placeholder="ข้อความ"></textarea>
      <button type="submit">ส่งข้อความ</button>
    </form>
  </section>
</body>
</html>""",
        """body{margin:0;font-family:system-ui,sans-serif;background:#020617;color:#e5e7eb;}
.contact{max-width:520px;margin:40px auto;padding:24px;background:#0b1120;border-radius:16px;box-shadow:0 18px 35px rgba(15,23,42,.8);}
input,textarea{width:100%;margin-bottom:12px;padding:8px;border-radius:8px;border:1px solid #1f2937;background:#020617;color:#e5e7eb;}
button{padding:8px 16px;border-radius:999px;border:none;background:#22c55e;color:#020617;font-weight:bold;}""",
    )

    # 14: Personal Link Page
    add_template(
        "Link in Bio",
        "Profile",
        """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Links</title>
</head>
<body>
  <div class="card">
    <img class="avatar" src="https://placehold.co/80x80" alt="avatar">
    <h2>ชื่อของคุณ</h2>
    <p>คำอธิบายสั้น ๆ</p>
    <a href="#" class="btn">YouTube</a>
    <a href="#" class="btn">Facebook</a>
    <a href="#" class="btn">อื่น ๆ</a>
  </div>
</body>
</html>""",
        """body{margin:0;display:flex;align-items:center;justify-content:center;height:100vh;background:#020617;color:#e5e7eb;font-family:system-ui,sans-serif;}
.card{text-align:center;background:#0b1120;padding:24px;border-radius:20px;box-shadow:0 20px 40px rgba(15,23,42,.9);}
.avatar{border-radius:999px;margin-bottom:12px;}
.btn{display:block;margin-top:8px;padding:8px 16px;border-radius:999px;background:#1d4ed8;color:white;text-decoration:none;}""",
    )

    # 15: Game Landing
    add_template(
        "Game Landing",
        "Game",
        """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Game Landing</title>
</head>
<body>
  <section class="hero">
    <h1>ชื่อเกมของคุณ</h1>
    <p>ข้อความโปรโมตมัน ๆ</p>
    <button>ดาวน์โหลดเดี๋ยวนี้</button>
  </section>
</body>
</html>""",
        """body{margin:0;font-family:system-ui,sans-serif;background:#020617;color:#e5e7eb;}
.hero{text-align:center;padding:80px 20px;background:radial-gradient(circle at top,#f97316,#020617);}
button{margin-top:12px;padding:10px 20px;border-radius:999px;border:none;background:#facc15;color:#1f2937;font-weight:bold;}""",
    )

    for t in base_templates:
        tpl = Template(
            name=t["name"],
            category=t.get("category"),
            thumbnail=None,
            html_content=t["html_content"],
            css_content=t["css_content"],
            js_content=t["js_content"],
        )
        db.session.add(tpl)

    db.session.commit()
    print(f"[INIT] Created {len(base_templates)} default templates (v1.2)")


if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
