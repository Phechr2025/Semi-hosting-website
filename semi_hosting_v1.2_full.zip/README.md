# Mini Hosting Panel v1.2 (Flask)

เวอร์ชัน 1.2 ของระบบโฮสติ้งขนาดเล็ก:

- เพิ่มเทมเพลตเว็บไซต์เริ่มต้นมากกว่า 15 แบบ (Landing, Portfolio, Blog, Shop, Docs ฯลฯ)
- เพิ่มพื้นที่เก็บโค้ดหลายภาษา (Multi-language workspace) ต่อเว็บไซต์
  - รองรับภาษาเช่น: python, javascript, typescript, php, ruby, go, c, cpp, csharp, java, kotlin, swift, rust, lua, haskell, dart, r, sql, bash, html, css
  - ใช้สำหรับเก็บโค้ดโปรเจกต์ที่เกี่ยวข้องในที่เดียว
  - การเรนเดอร์หน้าเว็บยังใช้ HTML/CSS/JS ตามเดิม

## การติดตั้ง

1) ติดตั้ง dependency พื้นฐาน (บน Ubuntu)

    sudo apt update && sudo apt install -y python3 python3-venv python3-pip

2) แตกไฟล์โปรเจกต์ แล้วเข้าโฟลเดอร์

    unzip semi_hosting_v1_2.zip -d semi_hosting_v1_2
    cd semi_hosting_v1_2

3) สร้าง virtualenv และติดตั้งแพ็กเกจ

    python3 -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt

4) ตั้งค่าบัญชีแอดมินเริ่มต้น (ไม่จำเป็นแต่แนะนำให้เปลี่ยน)

    export DEFAULT_ADMIN_USER="myadmin"
    export DEFAULT_ADMIN_PASS="strongpassword"
    export SECRET_KEY="random-secret-key"

5) รันแอป

    python app.py

แอปจะเปิดที่พอร์ต 8000

## การใช้งาน

- หน้าแรก: http://your-vps-ip:8000/
- สมัครสมาชิก / เข้าสู่ระบบ จากเมนูด้านบน
- แดชบอร์ดผู้ใช้: /user/dashboard
- สร้างเว็บไซต์ใหม่: เลือกเทมเพลต หรือโหมดเขียนโค้ดเอง
- ในหน้าแก้ไขเว็บไซต์:
  - แท็บ HTML / CSS / JS สำหรับเนื้อหาที่ใช้เรนเดอร์หน้าเว็บจริง
  - ส่วน Multi-language workspace ใช้เก็บโค้ดภาษาอื่น ๆ (Python, PHP, C ฯลฯ) ต่อเว็บไซต์

## หมายเหตุ

ระบบนี้ไม่ได้รันโค้ดภาษาอื่น ๆ โดยอัตโนมัติ
พื้นที่ Multi-language workspace ใช้เพื่อจัดเก็บ/แก้ไขโค้ดหลายภาษาในโปรเจกต์เดียวกัน
ส่วนที่แสดงผลบนเว็บจะยังใช้ HTML/CSS/JS ตามปกติ
